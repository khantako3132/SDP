<?php

interface Eatable
{
    public function eat();
}

interface Workable
{
    public function work();
}
class HumanWorker implements Eatable, Workable
{
    public function work()
    {
        echo "Human is working\n";
    }

    public function eat()
    {
        echo "Human is eating\n";
    }
}
class RobotWorker implements Workable
{
    public function work()
    {
        echo "Robot is working\n";
    }
}

// Usage
$human = new HumanWorker();
$human->work();
$human->eat();
