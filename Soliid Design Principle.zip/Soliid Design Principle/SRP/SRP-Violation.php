<?php

class User
{
    private $name;
    private $email;

    public function __construct($name, $email)
    {
        $this->name = $name;
        $this->email = $email;
    }

    public function getName()
    {
        return $this->name;
    }

    public function getEmail()
    {
        return $this->email;
    }
}

class UserRepository
{
    // Respo1 User data
    public function save()
    {
        // save user data
        echo "Saving user data to database\n";
    }
}

class EmailService
{
    // Respo 2 Email.
    public function sendEmail($email, $message)
    {
        // send email
        echo "Sending email to " . $email . ": " . $message . "\n";
    }
}

// Usage
$user = new User("John Doe", "john@example.com");
$userRepository = new UserRepository;
$userRepository->save();

$emailService = new EmailService;
$emailService->sendEmail($user->getEmail(), "Welcome to our service!");
