<?php

interface Flyable
{
    public function fly();
}
class Bird
{
}

class Sparrow extends Bird implements Flyable
{
    public function fly()
    {
        echo "Sparrow is Flying with love in the sky\n";
    }
}

class Parrot extends Bird implements Flyable
{
    public function fly()
    {
        echo "Parrot is Flying with groups in the sky\n";
    }
}

class Penguin extends Bird
{
}

function makeBirdFly(Flyable $bird)
{
    $bird->fly();
}

// Usage
$sparrow = new Sparrow();
makeBirdFly($sparrow); 

$parrot = new Parrot();
makeBirdFly($parrot); 

$penguin = new Penguin();
//makeBirdFly($penguin); // Error Exception: Penguins can't fly
